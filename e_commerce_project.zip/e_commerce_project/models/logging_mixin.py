from logger import logger

class LoggingMixin: # Resposta 2a
    def log(self, message, level="info"):
        """
        Regista mensagens de log com diferentes níveis.
        :param message: Mensagem a ser registada.
        :param level: Nível do log (info, warning, error, debug, critical).
        """
        if level == "info":
            logger.info(f"{self.__class__.__name__}: {message}")
        elif level == "warning":
            logger.warning(f"{self.__class__.__name__}: {message}")
        elif level == "error":
            logger.error(f"{self.__class__.__name__}: {message}")
        elif level == "debug":
            logger.debug(f"{self.__class__.__name__}: {message}")
        elif level == "critical":
            logger.critical(f"{self.__class__.__name__}: {message}")
        else:
            logger.info(f"{self.__class__.__name__}: {message}")
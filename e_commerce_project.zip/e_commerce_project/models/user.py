# User class

from logger import logger

class User(LoggingMixin):
    def __init__(self, id, name, email, address):
        self.id = id
        self.name = name
        self.email = self.validate_email(email)
        self.address = address
        self.order_history = []
        self.log(f"User {self.name} created with ID: {self.id}")

    @classmethod
    def from_dict(cls, data):
        """
        Cria uma instância de User a partir de um dicionário.
        """
        user = cls(
            id=data["id"],
            name=data["name"],
            email=data["email"],
            address=data["address"]
        )
        user.log(f"User {user.name} created from dictionary.")
        return user

    def to_dict(self):
        """
        Retorna a representação do Utilizador em forma de dicionário.
        """
        data = {
            "id": self.id,
            "name": self.name,
            "email": self.email,
            "address": self.address
        }
        self.log(f"User {self.name} converted to dictionary.")
        return data

    def validate_email(self, email):
        if "@" not in email or "." not in email:
            self.log(f"Invalid email format for {self.name}: {email}", level="error")
            raise ValueError("Formato de email inválido.")
        self.log(f"Email {email} validated for {self.name}.")
        return email

    def add_order(self, order):
        """
        Adiciona um pedido ao histórico do Utilizador.
        """
        self.order_history.append(order)
        self.log(f"Order {order.id} added to {self.name}'s order history.")

    def display_order_history(self):
        """
        Exibe o histórico de pedidos do Utilizador.
        """
        if not self.order_history:
            self.log(f"No orders found for {self.name}.", level="info")
            print(f"Nenhum pedido encontrado para {self.name}.")
        else:
            self.log(f"Displaying order history for {self.name}.", level="info")
            print(f"Histórico de pedidos de {self.name}:")
            for order in self.order_history:
                order.display_details()

    def get_latest_order(self):
        if self.order_history:
            self.log(f"Fetching the latest order for {self.name}.")
            return self.order_history[-1]
        self.log(f"No orders found for {self.name}.", level="info")
        return None

    def __str__(self):
        return f"Utilizador: {self.name}, Email: {self.email}, Endereço: {self.address}"

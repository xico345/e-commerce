# Order Class

from datetime import datetime
from logger import logger

class Order(LoggingMixin):
    def __init__(self, id, user_id, items, timestamp=None):
        """
        items: lista de dicionários no formato {"product": <Product>, "quantity": <int>}
        """
        self.id = id
        self.user_id = user_id
        self.items = items
        self.timestamp = timestamp if timestamp is not None else datetime.now()
        self.status = "Pendente"
        self.log(f"Order created. ID: {self.id}, User ID: {self.user_id}, Status: {self.status}.")

    @classmethod
    def from_dict(cls, data, products_lookup):
        """
        Cria uma instância de Order a partir de um dicionário.
        O parâmetro 'products_lookup' é um dicionário que mapeia product_id para o objeto Product.
        """
        items = []
        for item in data["items"]:
            product = products_lookup.get(item["product_id"])
            if product is not None:
                items.append({"product": product, "quantity": item["quantity"]})
            else:
                logger.warning(f"Warning: Product with ID {item['product_id']} not found.")
        timestamp = datetime.fromisoformat(data["timestamp"])
        order = cls(data["id"], data["user_id"], items, timestamp)
        order.status = data.get("status", "Pendente")
        order.log(f"Order created from dictionary. ID: {order.id}, Status: {order.status}.")
        return order

    def to_dict(self):
        """
        Retorna a representação do pedido em forma de dicionário.
        """
        data = {
            "id": self.id,
            "user_id": self.user_id,
            "items": [{"product_id": item["product"].id, "quantity": item["quantity"]} for item in self.items],
            "timestamp": self.timestamp.isoformat(),
            "status": self.status
        }
        self.log(f"Order converted to dictionary. ID: {self.id}, Status: {self.status}.")
        return data

    def display_details(self):
        print(f"Pedido ID: {self.id} - Utilizador ID: {self.user_id} - Status: {self.status}")
        print("Itens do pedido:")
        for item in self.items:
            print(f"  {item['product'].name} - Quantidade: {item['quantity']}")
        print(f"Data do pedido: {self.timestamp.isoformat()}")
        self.log(f"Displayed details for order ID: {self.id}, Status: {self.status}.")

    def update_status(self, new_status):
        """
        Update the status of the order and log the change.
        """
        old_status = self.status
        self.status = new_status
        self.log(f"Order status updated. ID: {self.id}, from {old_status} to {new_status}.")

    def __str__(self):
        return f"Pedido ID: {self.id} - Usuário ID: {self.user_id} - Status: {self.status} - Data: {self.timestamp.isoformat()}"

# Class for products with a discount, inheriting from Product

from product import Product
from logger import logger

class DiscountedProduct(Product): # Resposta 1a.
    def __init__(self, id, name, price, stock, description="", discount=0.0):
        super().__init__(id, name, price, stock, description)
        self.discount = discount  # uses the setter for validation
        self.log(f"Discounted product {self.name} created with discount: {self.discount * 100}%.")

    @property
    def discount(self):
        return self._discount

    @discount.setter
    def discount(self, value):
        if not (0 <= value <= 1):
            self.log(f"Invalid discount value: {value}. Discount must be between 0 and 1.", level="error")
            raise ValueError("O desconto deve estar entre 0 e 1.")
        self._discount = value
        self.log(f"Discount for product {self.name} set to {self.discount * 100}%.")

    @classmethod
    def from_dict(cls, data):
        """
        Cria uma instância de DiscountedProduct a partir de um dicionário.
        """
        product = cls(
            id=data["id"],
            name=data["name"],
            price=data["price"],
            stock=data["stock"],
            description=data.get("description", ""),
            discount=data.get("discount", 0.0)
        )
        product.log(f"Discounted product {product.name} created from dictionary with discount: {product.discount * 100}%.")
        return product

    def to_dict(self):
        """
        Retorna a representação do objeto em forma de dicionário, incluindo o desconto.
        """
        data = super().to_dict()
        data["discount"] = self.discount
        self.log(f"Product {self.name} converted to dictionary with discount: {self.discount * 100}%.")
        return data

    def display_info(self): # Resposta 1a.
        discounted_price = self.price * (1 - self.discount)
        print(f"{self.name} - Preço Original: ${self.price:.2f} - Preço com Desconto: ${discounted_price:.2f} - Stock: {self.stock}")
        self.log(f"Displayed info for product {self.name}. Discounted price: ${discounted_price:.2f}.")

    def calculate_total(self, quantity): # Resposta 1c.
        discounted_price = self.price * (1 - self.discount)
        return discounted_price * quantity

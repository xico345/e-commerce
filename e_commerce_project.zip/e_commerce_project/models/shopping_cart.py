from logger import logger

class ShoppingCart(LoggingMixin):
    def __init__(self):
        self.items = {}  # {product: quantity}
        self.log("Shopping cart created.")

    # Add a product to the cart
    def add_product(self, product, quantity):
        if quantity <= 0:
            raise ValueError("Quantity must be greater than zero.")
        if product.stock < quantity:
            self.log(f"Insufficient stock for {product.name}. Available: {product.stock}.", level="warning")
            raise ValueError(f"Insufficient stock for {product.name}. Available: {product.stock}.")
        
        self.items[product] = self.items.get(product, 0) + quantity
        self.log(f"{quantity} unit(s) of {product.name} added to the cart.")

    # Remove a product from the cart
    def remove_product(self, product):
        if product in self.items:
            del self.items[product]
            self.log(f"{product.name} removed from the cart.")
        else:
            self.log(f"{product.name} is not in the cart.", level="warning")

    # Calculate the total cost of the cart
    def calculate_total(self):
        total = sum(product.price * quantity for product, quantity in self.items.items())
        self.log(f"Total cost of the cart: ${total:.2f}")
        return total

    # Display items in the cart
    def display_items(self):
        if not self.items:
            self.log("Your cart is empty.", level="info")
            print("Your cart is empty.")
            return
        self.log("Items in the cart displayed.", level="info")
        print("Items in the Cart:")
        for product, quantity in self.items.items():
            print(f"{product.name} - Quantity: {quantity}")

    # Update the quantity of an existing product in the cart
    def update_quantity(self, product, new_quantity):
        if new_quantity <= 0:
            raise ValueError("Quantity must be greater than zero.")
        if product not in self.items:
            self.log(f"{product.name} is not in the cart.", level="warning")
            print(f"{product.name} is not in the cart.")
            return
        if product.stock < new_quantity:
            self.log(f"Insufficient stock for {product.name}. Available: {product.stock}.", level="warning")
            raise ValueError(f"Insufficient stock for {product.name}. Available: {product.stock}.")
        
        self.items[product] = new_quantity
        self.log(f"Updated {product.name} quantity to {new_quantity}.")

    # Clear the entire cart
    def clear_cart(self):
        self.items.clear()
        self.log("Cart has been cleared.")
        print("Cart has been cleared.")
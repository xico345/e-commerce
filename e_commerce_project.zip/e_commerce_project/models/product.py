# Product Class

from models.logging_mixin import LoggingMixin

class Product(LoggingMixin): # Resposta 1a.
    def __init__(self, id, name, price, stock, description=""):
        if price <= 0:
            self.log("Tentativa de criar um produto com preço inválido.", "error")
            raise ValueError("O preço deve ser positivo.")
        if not name:
            self.log("Tentativa de criar um produto sem nome.", "error")
            raise ValueError("O nome não pode ser vazio.")
        
        self.id = id
        self.name = name
        self.price = price
        self.stock = stock
        self.description = description
        self.log(f"Produto {self.name} criado com sucesso. ID: {self.id}")

    @classmethod
    def from_dict(cls, data):
        instance = cls(
            id=data["id"],
            name=data["name"],
            price=data["price"],
            stock=data["stock"],
            description=data.get("description", "")
        )
        instance.log(f"Produto criado a partir de dicionário: {instance.name}")
        return instance
    
    def to_dict(self):
        data = {
            "id": self.id,
            "name": self.name,
            "price": self.price,
            "stock": self.stock,
            "description": self.description
        }
        self.log(f"Produto convertido para dicionário: {self.name}")
        return data
    
    def update_stock(self, quantity):
        if quantity > self.stock:
            self.log(f"Erro: Tentativa de vender {quantity}, mas stock disponível é {self.stock}.", "error")
            raise ValueError("Stock insuficiente!")
        
        self.stock -= quantity
        self.log(f"Stock atualizado. Quantidade deduzida: {quantity}. Stock atual: {self.stock}")

    def restock(self, quantity):
        if quantity < 0:
            self.log("Tentativa de reposição de stock com valor negativo.", "error")
            raise ValueError("A quantidade para reposição deve ser positiva.")
        
        self.stock += quantity
        self.log(f"Reabastecimento realizado. Quantidade adicionada: {quantity}. Stock atual: {self.stock}")

    def apply_discount(self, discount_percentage):
        if not (0 <= discount_percentage <= 100):
            self.log(f"Erro ao aplicar desconto de {discount_percentage}%. Valor inválido.", "error")
            raise ValueError("O desconto deve estar entre 0 e 100.")
        
        old_price = self.price
        self.price -= self.price * (discount_percentage / 100)
        self.log(f"Desconto aplicado: {discount_percentage}%. Preço alterado de {old_price} para {self.price}")

    def display_info(self): # Resposta 1a.
        info = f"{self.name} - Preço: ${self.price:.2f} - Stock: {self.stock}"
        print(info)
        self.log(f"Informações exibidas: {info}")

    def __str__(self):
        return f"{self.name} - Preço: ${self.price:.2f} - Stock: {self.stock} - Descrição: {self.description}"

    def calculate_total(self, quantity): # Resposta 1c.
        return self.price * quantity
import logging # Resposta 2a
import os

# Get the base directory dynamically
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOGS_DIR = os.path.join(BASE_DIR, "logs")

# Create logs directory if it doesn't exist
if not os.path.exists(LOGS_DIR):
    os.makedirs(LOGS_DIR)

# Set the log file path
log_file = os.path.join(LOGS_DIR, "app.log")

# Set up the logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)  # Set the logging level to INFO (you can change this to DEBUG, ERROR, etc.)

# Create a file handler to write logs to a file
file_handler = logging.FileHandler(log_file)
file_handler.setLevel(logging.INFO)

# Create a console handler to display logs in the terminal
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)

# Set up a log formatter
log_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
file_handler.setFormatter(log_formatter)
console_handler.setFormatter(log_formatter)

# Add handlers to the logger
logger.addHandler(file_handler)
logger.addHandler(console_handler)
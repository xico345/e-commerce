# Handles the loading, saving and initialization of the data

import os
import json
from models.product import Product
from models.user import User
from models.order import Order
from datetime import datetime
from logger import logger

# Get the base directory dynamically
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")

PRODUCTS_FILE = os.path.join(DATA_DIR, "products.json")
USERS_FILE = os.path.join(DATA_DIR, "users.json")
ORDERS_FILE = os.path.join(DATA_DIR, "orders.json")

def load_json(file_path):
    """Safely loads JSON data from a file, returns an empty list if file is missing/corrupt."""
    try:
        if not os.path.exists(file_path):
            logger.warning(f"{file_path} not found. Returning empty data.")
            return []
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            logger.info(f"Loaded data from {file_path}.")
            return data
    except (json.JSONDecodeError, IOError) as e:
        logger.error(f"Failed to load {file_path}. Error: {e}. Using default empty data.")
        return []

def save_json(data, file_path):
    """Safely saves data to a JSON file."""
    try:
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)
            logger.info(f"Data successfully saved to {file_path}.")
    except IOError as e:
        logger.error(f"Could not save data to {file_path}. Error: {e}.")

def initialize_products():
    """Loads products from JSON and converts them into Product instances."""
    product_data = load_json(PRODUCTS_FILE)
    products = [Product.from_dict(p) for p in product_data]  # Using factory method
    logger.info(f"Initialized {len(products)} products.")
    return products

def initialize_users():
    """Loads users from JSON and converts them into User instances."""
    user_data = load_json(USERS_FILE)
    users = [User.from_dict(u) for u in user_data]
    logger.info(f"Initialized {len(users)} users.")
    return users

def initialize_orders(products):
    """Loads orders from JSON and ensures valid product references."""
    order_data = load_json(ORDERS_FILE)
    orders = []

    for order in order_data:
        order_items = []
        for item in order["items"]:
            product = next((p for p in products if p.id == item["product_id"]), None)
            if product:
                order_items.append({"product": product, "quantity": item["quantity"]})
            else:
                logger.warning(f"Product ID {item['product_id']} in order {order['id']} does not exist.")
        
        orders.append(Order(order["id"], order["user_id"], order_items, datetime.fromisoformat(order["timestamp"])))
    
    logger.info(f"Initialized {len(orders)} orders.")
    return orders

def save_products(products):
    """Saves product data to JSON."""
    product_data = [p.to_dict() for p in products]
    save_json(product_data, PRODUCTS_FILE)

def save_users(users):
    """Saves user data to JSON."""
    user_data = [u.to_dict() for u in users]
    save_json(user_data, USERS_FILE)

def save_orders(orders):
    """Saves order data to JSON."""
    order_data = [{
        "id": o.id,
        "user_id": o.user_id,
        "items": [{"product_id": item["product"].id, "quantity": item["quantity"]} for item in o.items],
        "timestamp": o.timestamp.isoformat()
    } for o in orders]
    save_json(order_data, ORDERS_FILE)
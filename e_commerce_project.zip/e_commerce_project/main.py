import os
from datetime import datetime
from data_handler import (
    initialize_products,
    initialize_users,
    initialize_orders,
    save_products,
    save_users,
    save_orders
)
from models.shopping_cart import ShoppingCart
from models.order import Order
from models.user import User
from logger import logger

def login(users):
    """Realiza o login do utilizador. Se não encontrado, pergunta se deseja registar."""
    print("=== Login ===")
    username = input("Digite o seu nome de utilizador: ").strip()
    user = next((u for u in users if u.name.lower() == username.lower()), None)
    if not user:
        print("Utilizador não encontrado.")
        choice = input("Deseja se registar? (s/n): ").strip().lower()
        if choice == 's':
            return register_user(users)
        else:
            return None
    else:
        print(f"Bem-vindo(a) de volta, {user.name}!")
        logger.info(f"User {user.name} logged in.")
        return user

def register_user(users):
    """Regista um novo utilizador e o adiciona à lista de utilizadores."""
    print("=== Registo de Utilizador ===")
    name = input("Digite o nome do utilizador: ").strip()
    email = input("Digite o email do utilizador: ").strip()
    address = input("Digite o endereço do utilizador: ").strip()
    # Gera um ID para o novo utilizador: usa o maior ID existente + 1 ou 1 se a lista estiver vazia.
    user_id = max([u.id for u in users]) + 1 if users else 1
    new_user = User(user_id, name, email, address)
    users.append(new_user)
    print(f"Utilizador {name} criado com sucesso!")
    logger.info(f"New user registered: {name}, ID: {user_id}")
    return new_user

def main_menu():
    """Exibe o menu principal e retorna a opção escolhida."""
    print("\nSelecione uma opção:")
    print("1. Ver Produtos")
    print("2. Criar Pedido")
    print("3. Ver Meus Pedidos")
    print("4. Logout")
    print("5. Sair")
    return input("Digite a sua escolha (1-5): ").strip()

def main():
    # Inicializa os dados a partir dos arquivos JSON
    products = initialize_products()
    users = initialize_users()
    orders = initialize_orders(products)

    # Cria um dicionário de produtos para buscas eficientes (chave: nome em minúsculas)
    product_lookup = {p.name.lower(): p for p in products}

    # Solicita o login do utilizador (ou registo, se necessário)
    current_user = None
    while not current_user:
        current_user = login(users)

    # Loop principal do sistema
    while True:
        option = main_menu()

        if option == "1":
            print("\n=== Produtos Disponíveis ===")
            for product in products:
                product.display_info()

        elif option == "2":
            print("\n=== Criar Pedido ===")
            cart = ShoppingCart()
            while True:
                prod_name = input("Digite o nome do produto para adicionar ao carrinho (ou 'done' para finalizar): ").strip()
                if prod_name.lower() == "done":
                    break
                # Busca o produto usando o dicionário de lookup
                product = product_lookup.get(prod_name.lower())
                if not product:
                    print("Produto não encontrado!")
                    continue

                # Solicita a quantidade com tratamento de erro
                while True:
                    try:
                        quantity = int(input(f"Digite a quantidade para {product.name}: ").strip())
                        if quantity <= 0:
                            print("A quantidade deve ser um número positivo.")
                            continue
                        if quantity > product.stock:
                            print(f"Stock insuficiente. Apenas {product.stock} unidades disponíveis.")
                            continue
                        break
                    except ValueError:
                        print("Entrada inválida! Por favor, digite um número válido.")
                try:
                    cart.add_product(product, quantity)
                except ValueError as ve:
                    print(str(ve))

            if not cart.items:
                print("Carrinho vazio. Pedido cancelado.")
                continue

            total = cart.calculate_total()
            # Gera um ID para o pedido: maior ID existente + 1 ou 1 se não houver pedidos
            order_id = max([o.id for o in orders]) + 1 if orders else 1
            # Prepara os itens do pedido: cada item é um dicionário com o produto e a quantidade
            order_items = [{"product": prod, "quantity": qty} for prod, qty in cart.items.items()]
            new_order = Order(order_id, current_user.id, order_items, datetime.now())
            orders.append(new_order)
            # Associa o pedido ao histórico do utilizador
            if hasattr(current_user, "add_order"):
                current_user.add_order(new_order)
            print(f"Pedido realizado com sucesso para {current_user.name}! Total: ${total:.2f}")
            logger.info(f"Order {new_order.id} created for user {current_user.name}. Total: ${total:.2f}")

        elif option == "3":
            print("\n=== Meus Pedidos ===")
            # Filtra os pedidos do utilizador atual
            user_orders = [o for o in orders if o.user_id == current_user.id]
            if not user_orders:
                print("Nenhum pedido encontrado.")
            else:
                for order in user_orders:
                    order.display_details()

        elif option == "4":
            print("Realizando logout...")
            logger.info(f"User {current_user.name} logged out.")
            current_user = None
            while not current_user:
                current_user = login(users)

        elif option == "5":
            # Salva os dados antes de sair
            save_products(products)
            save_users(users)
            save_orders(orders)
            print("Dados guardados. Até logo!")
            logger.info("Data saved. Exiting the application.")
            break

        else:
            print("Opção inválida, por favor tente novamente.")

if __name__ == "__main__":
    main()
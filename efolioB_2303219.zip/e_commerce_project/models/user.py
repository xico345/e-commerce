# User Class

class User:
    def __init__(self, id, name, email, address):
        self.__id = id
        self.__name = name
        self.__email = self.validate_email(email)
        self.__address = address
        self.__order_history = []

    @property
    def name(self):
        return self.__name

    @property
    def email(self):
        return self.__email

    @property
    def address(self):
        return self.__address

    @property
    def order_history(self):
        return self.__order_history.copy()

    def validate_email(self, email):
        if "@" not in email or "." not in email:
            raise ValueError("Invalid email format.")
        return email

    # Add an order to the user's history
    def add_order(self, order):
        self.__order_history.append(order)

    # Display the user's order history
    def display_order_history(self):
        if not self.__order_history:
            print(f"No orders found for {self.__name}.")
        else:
            print(f"Order history for {self.__name}:")
            for order in self.__order_history:
                order.display_details()

    # Get the latest order
    def get_latest_order(self):
        if self.__order_history:
            return self.__order_history[-1]
        return None

    # String representation of the user
    def __str__(self):
        return f"User: {self.__name}, Email: {self.__email}, Address: {self.__address}"
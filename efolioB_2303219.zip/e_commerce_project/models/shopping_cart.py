# ShoppingCart Class

class ShoppingCart:
    def __init__(self):
        self.items = {}  # {product: quantity}

    # Add a product to the cart
    def add_product(self, product, quantity):
        if quantity <= 0:
            raise ValueError("Quantity must be greater than zero.")
        if product.stock < quantity:
            raise ValueError(f"Insufficient stock for {product.name}. Available: {product.stock}.")
        
        self.items[product] = self.items.get(product, 0) + quantity
        print(f"{quantity} unit(s) of {product.name} added to the cart.")

    # Remove a product from the cart
    def remove_product(self, product):
        if product in self.items:
            del self.items[product]
            print(f"{product.name} removed from the cart.")
        else:
            print(f"{product.name} is not in the cart.")

    # Calculate the total cost of the cart
    def calculate_total(self):
        total = sum(product.price * quantity for product, quantity in self.items.items())
        print(f"Total cost of the cart: ${total:.2f}")
        return total

    # Display items in the cart
    def display_items(self):
        if not self.items:
            print("Your cart is empty.")
            return
        print("Items in the Cart:")
        for product, quantity in self.items.items():
            print(f"{product.name} - Quantity: {quantity}")

    # Update the quantity of an existing product in the cart
    def update_quantity(self, product, new_quantity):
        if new_quantity <= 0:
            raise ValueError("Quantity must be greater than zero.")
        if product not in self.items:
            print(f"{product.name} is not in the cart.")
            return
        if product.stock < new_quantity:
            raise ValueError(f"Insufficient stock for {product.name}. Available: {product.stock}.")
        
        self.items[product] = new_quantity
        print(f"Updated {product.name} quantity to {new_quantity}.")

    # Clear the entire cart
    def clear_cart(self):
        self.items.clear()
        print("Cart has been cleared.")
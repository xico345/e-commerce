# Product Class

class Product:
    def __init__(self, id, name, price, stock, description=""):
        if price <= 0:
            raise ValueError("Price must be positive.")
        if not name:
            raise ValueError("Name cannot be empty.")
        self.__id = id
        self.__name = name
        self.__price = price
        self.__stock = stock
        self.__description = description

    # Getters and setters for encapsulation
    @property
    def id(self):
        return self.__id

    @property
    def name(self):
        return self.__name

    @property
    def price(self):
        return self.__price

    @property
    def stock(self):
        return self.__stock

    @property
    def description(self):
        return self.__description

    @description.setter
    def description(self, new_description):
        self.__description = new_description

    # Update stock safely
    def update_stock(self, quantity):
        if quantity > self.__stock:
            raise ValueError("Insufficient stock!")
        self.__stock -= quantity

    # Restock the product
    def restock(self, quantity):
        if quantity < 0:
            raise ValueError("Quantity to restock must be positive.")
        self.__stock += quantity

    # Apply discount to product price
    def apply_discount(self, discount_percentage):
        if not (0 <= discount_percentage <= 100):
            raise ValueError("Discount percentage must be between 0 and 100.")
        self.__price -= self.__price * (discount_percentage / 100)

    # Display product information
    def display_info(self):
        print(f"{self.__name} - Price: ${self.__price:.2f} - Stock: {self.__stock}")

    # String representation of the product
    def __str__(self):
        return f"{self.__name} - Price: ${self.__price:.2f} - Stock: {self.__stock} - Description: {self.__description}"
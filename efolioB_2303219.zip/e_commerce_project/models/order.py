# Order Class

from datetime import datetime

class Order:
    def __init__(self, user, items, total):
        self.user = user
        self.items = items
        self.total = total
        self.status = "Pending"
        self.timestamp = datetime.now()

    def validate_total(self):
        calculated_total = sum(product.price * quantity for product, quantity in self.items.items())
        if self.total != calculated_total:
            raise ValueError("Total does not match the calculated amount.")

    def process_order(self):
        self.validate_total()
        for product, quantity in self.items.items():
            product.update_stock(quantity)
        self.status = "Processed"
        print(f"Order processed successfully! ({self.timestamp})")

    def update_status(self, new_status):
        valid_statuses = ["Pending", "Processed", "In Transit", "Delivered"]
        if new_status not in valid_statuses:
            raise ValueError(f"Invalid status: {new_status}")
        self.status = new_status

    def display_details(self):
        print(f"Order from {self.user.name} - Total: ${self.total:.2f} - Status: {self.status}")
        print("Items in the order:")
        for product, quantity in self.items.items():
            print(f"{product.name} - Quantity: {quantity}")

    def __str__(self):
        return f"Order from {self.user.name} - Total: ${self.total:.2f} - Status: {self.status} - Date: {self.timestamp}"
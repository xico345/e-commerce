# Class for products with a discount, inheriting from Product

from product import Product

class DiscountedProduct(Product):

    def __init__(self, id, name, price, stock, description="", discount=0.0):

        #param discount: Discount rate (between 0 and 1) applied to the product (default is 0)
        
        super().__init__(id, name, price, stock, description)
        self.__discount = discount

    #Return the current discount value.
    @property
    def discount(self):
        return self.__discount

    @discount.setter
    def discount(self, value):
        """
        Set the discount value (must be between 0 and 1).
        value: Discount value as a decimal (example: 0.2 for 20% off)
        """
        if not (0 <= value <= 1):
            raise ValueError("Discount must be between 0 and 1.")
        self.__discount = value

    def display_info(self):
        """
        Display the product's information, including the discounted price.
        The discounted price is calculated as the original price minus the discount.
        """
        discounted_price = self.price * (1 - self.__discount)
        print(f"{self.name} - Original Price: ${self.price:.2f} - Discounted Price: ${discounted_price:.2f} - Stock: {self.stock}")
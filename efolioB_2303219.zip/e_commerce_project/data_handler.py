# Handles the loading, saving and initialization of the data

import json
import os
from models.product import Product
from models.discount import DiscountedProduct
from models.user import User
from models.order import Order

# Function to load data from JSON files
def load_data():
    # Check if the file exists, if not create them as empty files
    if not os.path.exists("data/products.json"):
        with open("data/products.json", "w") as f:
            json.dump([], f)
    
    if not os.path.exists("data/users.json"):
        with open("data/users.json", "w") as f:
            json.dump([], f)
    
    if not os.path.exists("data/orders.json"):
        with open("data/orders.json", "w") as f:
            json.dump([], f)

    # Read data from the JSON files
    with open("data/products.json", "r") as f:
        products_data = json.load(f)

    with open("data/users.json", "r") as f:
        users_data = json.load(f)

    with open("data/orders.json", "r") as f:
        orders_data = json.load(f)

    return products_data, users_data, orders_data

# Function to save data to JSON files
def save_data(products, users, orders):
    with open("data/products.json", "w") as f:
        json.dump([product.__dict__ for product in products], f)

    with open("data/users.json", "w") as f:
        json.dump([user.__dict__ for user in users], f)

    with open("data/orders.json", "w") as f:
        json.dump([order.__dict__ for order in orders], f)

# Initialize product objects
def initialize_products(products_data):
    products = []
    for data in products_data:
        if 'discount' in data:
            product = DiscountedProduct(**data)
        else:
            product = Product(**data)
        products.append(product)
    return products

# Initialize user objects
def initialize_users(users_data):
    users = []
    for data in users_data:
        user = User(**data)
        users.append(user)
    return users

# Initialize order objects
def initialize_orders(orders_data, users, products):
    orders = []
    for data in orders_data:
        user = next((u for u in users if u.id == data["user"]), None)
        items = {next((p for p in products if p.id == item["id"]), None): item["quantity"] for item in data["items"]}
        order = Order(user, items, data["total"])
        orders.append(order)
    return orders
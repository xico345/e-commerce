from models.product import Product
from models.shopping_cart import ShoppingCart
from models.order import Order
from models.user import User
from models.discount import DiscountedProduct
from data_handler import load_data, save_data, initialize_products, initialize_users, initialize_orders
import json
import os

# Main script to test the e-commerce system

def main():
    # Load the data
    products_data, users_data, orders_data = load_data()
    
    # Initialize objects
    products = initialize_products(products_data)
    users = initialize_users(users_data)
    orders = initialize_orders(orders_data, users, products)

    print("Welcome to the eCommerce System")

    # User interaction menu
    while True:
        print("\nSelect an option:")
        print("1. View Products")
        print("2. Create User")
        print("3. Create Order")
        print("4. View Orders")
        print("5. Exit")
        choice = input("Enter your choice (1-5): ")

        if choice == "1":
            print("Products available:")
            for product in products:
                product.display_info()

        elif choice == "2":
            name = input("Enter user name: ")
            email = input("Enter user email: ")
            address = input("Enter user address: ")
            user_id = len(users) + 1
            user = User(user_id, name, email, address)
            users.append(user)
            print(f"User {name} created!")

        elif choice == "3":
            user_name = input("Enter user name for the order: ")
            user = next((u for u in users if u.name == user_name), None)
            if not user:
                print("User not found!")
                continue
            
            cart = ShoppingCart()
            while True:
                product_name = input("Enter product name to add to cart (or 'done' to finish): ")
                if product_name.lower() == "done":
                    break
                product = next((p for p in products if p.name.lower() == product_name.lower()), None)
                if not product:
                    print("Product not found!")
                    continue

                # Ensure that the user enters a valid quantity
                while True:
                    try:
                        quantity = int(input(f"Enter quantity for {product.name}: "))
                        if quantity <= 0:
                            print("Quantity must be a positive number.")
                            continue
                        if quantity > product.stock:
                            print(f"Insufficient stock. Only {product.stock} units available.")
                            continue
                        break
                    except ValueError:
                        print("Invalid input! Please enter a valid number for quantity.")

                cart.add_product(product, quantity)

            total = cart.calculate_total()
            order = Order(user, cart.items, total)
            orders.append(order)
            print(f"Order placed for {user.name}, total: ${total:.2f}")
            user.add_order(order)

        elif choice == "4":
            print("Orders placed:")
            for order in orders:
                order.display_details()

        elif choice == "5":
            save_data(products, users, orders)
            print("Data saved. Goodbye!")
            break

        else:
            print("Invalid option, please try again.")

# Ensure the code runs only if this script is executed directly
if __name__ == "__main__":
    main()